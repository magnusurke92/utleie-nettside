
function calculatePrice() {
  const days = parseInt(document.getElementById('numDays').value);
  if (isNaN(days) || days < 1) {
    document.getElementById('result').innerText = 'Velg gyldig antall dager';
    return;
  }
  let price = 1500 + (days - 1) * 1000;
  document.getElementById('result').innerText = `Totalpris: ${price} kr`;
  document.getElementById('vipps').href = `https://vipps.no/pay?amount=${price}`;
  document.getElementById('vipps').innerText = `Betal ${price} kr med Vipps`;
}

function addToGoogleCalendar() {
  const startDate = document.getElementById('startDate').value;
  const days = parseInt(document.getElementById('numDays').value);
  if (!startDate || isNaN(days) || days < 1) {
    alert('Velg dato og antall dager');
    return;
  }
  const start = new Date(startDate);
  const end = new Date(start);
  end.setDate(start.getDate() + days);

  const format = (date) => date.toISOString().replace(/-|:|\.\d+/g, '');
  const startStr = format(start);
  const endStr = format(end);

  const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=Lift+og+Gravemaskin+Utleie&dates=${startStr}/${endStr}&details=Utleie+av+maskiner&location=Nordøyane&sf=true&output=xml`;
  window.open(url, '_blank');
}
